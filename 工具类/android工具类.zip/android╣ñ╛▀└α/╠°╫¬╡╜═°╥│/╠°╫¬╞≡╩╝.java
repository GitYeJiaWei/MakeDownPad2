Intent intent = new Intent(getThis(),Shopping.class);
            intent.putExtra("key", "touying");
            startActivity(intent);