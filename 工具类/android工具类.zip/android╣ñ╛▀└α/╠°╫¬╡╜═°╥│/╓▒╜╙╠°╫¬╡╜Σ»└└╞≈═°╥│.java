Uri uri = Uri.parse("http://www.sxx001.com/Wap/Goods/GoodsDetails?ID=4272");
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);