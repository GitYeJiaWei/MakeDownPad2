<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#FFFFFF"
    android:orientation="vertical" >
    <include
        android:id="@+id/header"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        layout="@layout/header" />
   	 <ListView 
   	     android:id="@+id/listview1"
   	     android:layout_width="match_parent"
   	     android:layout_height="wrap_content">
   	     
   	 </ListView>

</LinearLayout>
